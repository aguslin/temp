Write-Host "========================================"
Write-Host "  CDCP Agent - Code Signing"  
Write-Host "========================================"
Write-Host ""

# Check if running as admin
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "ERROR: Run this script as Administrator!" -ForegroundColor Red
    Write-Host "Right-click PowerShell -> Run as administrator" -ForegroundColor Yellow
    pause
    exit 1
}

# Get script directory
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$exePath = Join-Path $scriptDir "cdcp-agent.exe"

if (-not (Test-Path $exePath)) {
    Write-Host "ERROR: cdcp-agent.exe not found in $scriptDir" -ForegroundColor Red
    Write-Host "Put this script in the same folder as cdcp-agent.exe" -ForegroundColor Yellow
    pause
    exit 1
}

Write-Host "Creating self-signed certificate..." -ForegroundColor Cyan

# Create self-signed certificate
$cert = New-SelfSignedCertificate `
    -Type CodeSigningCert `
    -Subject "CN=CDCP Security Agent" `
    -CertStoreLocation "Cert:\CurrentUser\My" `
    -NotAfter (Get-Date).AddYears(5)

Write-Host "Certificate created!" -ForegroundColor Green
Write-Host "  Subject: $($cert.Subject)"
Write-Host "  Thumbprint: $($cert.Thumbprint)"
Write-Host "  Expires: $($cert.NotAfter)"
Write-Host ""

Write-Host "Signing cdcp-agent.exe..." -ForegroundColor Cyan

# Sign the executable
$result = Set-AuthenticodeSignature -FilePath $exePath -Certificate $cert

if ($result.Status -eq "Valid") {
    Write-Host "SUCCESS! cdcp-agent.exe is now signed!" -ForegroundColor Green
    Write-Host ""
    Write-Host "Publisher: CDCP Security Agent"
    Write-Host "Signed file: $exePath"
} else {
    Write-Host "ERROR: Signing failed - $($result.StatusMessage)" -ForegroundColor Red
}

Write-Host ""
Write-Host "NOTE: This certificate is self-signed." -ForegroundColor Yellow
Write-Host "It will show as 'CDCP Security Agent' on THIS machine." -ForegroundColor Yellow
Write-Host "On other machines, it may still show 'Unknown Publisher'." -ForegroundColor Yellow
Write-Host ""
pause
